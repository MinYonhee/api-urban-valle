package com.realstate.imobiliaria.exception;

public class ImovelValidationException extends RuntimeException {
    public ImovelValidationException(String message) {

        super(message);
    }
}