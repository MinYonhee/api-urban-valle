package com.realstate.imobiliaria.exception;

public class ImovelConflictException extends RuntimeException {
    public ImovelConflictException(String message) {

        super(message);
    }
}