package com.realstate.imobiliaria.model.contato;

public enum StatusContato {
    PENDENTE, EM_ANDAMENTO, CONCLUIDO
}