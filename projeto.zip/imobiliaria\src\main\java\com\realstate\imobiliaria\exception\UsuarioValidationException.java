package com.realstate.imobiliaria.exception;

public class UsuarioValidationException extends RuntimeException {
    public UsuarioValidationException(String message) {

        super(message);
    }
}