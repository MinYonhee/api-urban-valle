package com.realstate.imobiliaria.exception;

public class ImovelRelacionamentoInvalidoException extends RuntimeException {
    public ImovelRelacionamentoInvalidoException(String message) {

        super(message);
    }
}
