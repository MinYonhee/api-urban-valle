package com.realstate.imobiliaria.exception;

public class CredenciaisInvalidasException extends RuntimeException {
    public CredenciaisInvalidasException(String mensagem) {

        super(mensagem);
    }
}
