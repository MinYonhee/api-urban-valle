package com.realstate.imobiliaria.exception;

public class ContatoValidationException extends RuntimeException {
    public ContatoValidationException(String message) {

        super(message);
    }
}
